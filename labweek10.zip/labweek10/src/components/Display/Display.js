import React, { Component } from 'react'

export default class Display extends Component {
    constructor(props){
        
        super(props)
        this.state = {
            email: '',
            fullName: '',
            address: '',
            city: '',
            province: '',
            postalCode: '',

        }
    
    }

    handleClick(e) {
        e.preventDefault();

    }

    handleSubmit = (e) => {
        e.preventDefault();
    }

    handleInput = (e) => {
        e.preventDefault()
        const {name, value} = e.target
        
        this.setState({
            ...this.state,
            [name]: value
        })

    }

    render() {
        return (
            <div>

                <form onSubmit={this.handleSubmit}>
                Email: <input type='text' name='email' value={this.state.email} onChange = {this.handleInput} placeholder='Enter Email'/><br/>
                Full Name: <input type='text' name='fullName' value={this.state.fullName} onChange = {this.handleInput} placeholder='Enter Full Name'/><br/>
                Address: <input type='text' name='address' value={this.state.address} onChange = {this.handleInput} placeholder='Enter Address'/><br/>
                City: <input type='text' name='city' value={this.state.city} onChange = {this.handleInput} placeholder='Enter City'/><br/>
                Province: <input type='text' name='province' value={this.state.province} onChange = {this.handleInput} placeholder='Enter Province'/><br/>
                Postal Code: <input type='text' name='postalCode' value={this.state.postalCode} onChange = {this.handleInput} placeholder='Enter Postal Code'/><br/>
                
                <button value='TEST' name='btnSubmit' onClick={this.handleClick}>Submit</button>
                </form>
                <p> Email: {this.state.email }</p>
                <p> Full Name: {this.state.fullName }</p>
                <p> Address: {this.state.address }</p>
                <p> City: {this.state.city }</p>
                <p> Province: {this.state.province }</p>
                <p> Postal Code: {this.state.postalCode }</p>
            </div>

        

            
        )
    }
}